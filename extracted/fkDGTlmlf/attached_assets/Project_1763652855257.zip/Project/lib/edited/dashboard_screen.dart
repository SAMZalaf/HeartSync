import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:heartsync/app_strings.dart';
import 'package:heartsync/pairing_screen.dart'; // للانتقال إلى شاشة الربط
import 'package:heartsync/settings_screen.dart'; // للشاشة العامة للإعدادات
import 'package:heartsync/i_miss_you_settings_screen.dart'; // للشاشة المخصصة "اشتقت إليك"
import 'package:intl/intl.dart'; // لتنسيق التاريخ والوقت
import 'package:logger/logger.dart';
import 'dart:async'; // تم إضافة هذا الاستيراد لحل مشكلة StreamSubscription

final logger = Logger();
final GlobalKey<ScaffoldMessengerState> scaffoldMessengerKey =
    GlobalKey<ScaffoldMessengerState>();
final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  String? _partnerName;
  String? _partnerHeartCode;
  String? _myHeartCode;
  String? _partnerFcmToken;
  DateTime? _lastInteractionTime;
  final TextEditingController _messageController = TextEditingController();

  // لا يوجد متغير _sendIMissYouNotification هنا لتجنب التضارب.
  // الإعدادات الخاصة بـ "اشتقت إليك" تتم في IMissYouSettingsScreen.

  @override
  void initState() {
    super.initState();
    _loadPartnerInfo();
    _listenForInteractions();
  }

  Future<void> _loadPartnerInfo() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _partnerName = prefs.getString('partnerName');
      _partnerHeartCode = prefs.getString('partnerHeartCode');
      _myHeartCode = prefs.getString('userHeartCode');
      _partnerFcmToken = prefs.getString('partnerFcmToken');
    });
    if (_partnerHeartCode != null) {
      _fetchLastInteractionTime();
    }
  }

  Future<void> _fetchLastInteractionTime() async {
    if (_myHeartCode == null || _partnerHeartCode == null) return;
    try {
      final docSnapshot = await FirebaseFirestore.instance
          .collection('interactions')
          .doc('${_myHeartCode}_$_partnerHeartCode')
          .get();
      if (docSnapshot.exists) {
        final data = docSnapshot.data();
        if (data != null && data['timestamp'] != null) {
          setState(() {
            _lastInteractionTime = (data['timestamp'] as Timestamp).toDate();
          });
        }
      }
    } catch (e) {
      logger.e("Error fetching last interaction: $e");
    }
  }

  // تم حل مشكلة StreamSubscription هنا
  void _listenForInteractions() {
    if (_myHeartCode == null || _partnerHeartCode == null) {
      return;
    }

    FirebaseFirestore.instance
        .collection('interactions')
        .doc('${_partnerHeartCode}_$_myHeartCode')
        .snapshots()
        .listen((snapshot) {
      if (snapshot.exists && snapshot.data() != null) {
        final data = snapshot.data();
        if (data != null && data['timestamp'] != null) {
          setState(() {
            _lastInteractionTime = (data['timestamp'] as Timestamp).toDate();
          });
        }
      }
    });
    FirebaseFirestore.instance
        .collection('interactions')
        .doc('${_myHeartCode}_$_partnerHeartCode')
        .snapshots()
        .listen((snapshot) {
      if (snapshot.exists && snapshot.data() != null) {
        final data = snapshot.data();
        if (data != null && data['timestamp'] != null) {
          setState(() {
            _lastInteractionTime = (data['timestamp'] as Timestamp).toDate();
          });
        }
      }
    });
  }

  Future<void> _sendHeartbeat() async {
    if (_myHeartCode == null || _partnerHeartCode == null) {
      _displayMessage(
          currentStrings['noPartnerPaired'] ?? 'No partner paired yet.');
      return;
    }
    try {
      final interactionId = '${_myHeartCode}_$_partnerHeartCode';
      await FirebaseFirestore.instance
          .collection('interactions')
          .doc(interactionId)
          .set(
        {
          'senderId': _myHeartCode,
          'receiverId': _partnerHeartCode,
          'type': 'heartbeat',
          'timestamp': FieldValue.serverTimestamp(),
        },
        SetOptions(merge: true),
      );
      if (_partnerFcmToken != null && _partnerFcmToken!.isNotEmpty) {
        logger.i(
            'Sending heartbeat notification to partner FCM: $_partnerFcmToken');
        // TODO: يمكنك إضافة منطق إرسال إشعار FCM هنا باستخدام _partnerFcmToken
        // مثال (يتطلب firebase_messaging و cloud_functions):
        // await FirebaseMessaging.instance.sendMessage(
        //   to: _partnerFcmToken,
        //   data: {'type': 'heartbeat', 'senderId': _myHeartCode},
        // );
      }
      _displayMessage(currentStrings['heartbeatSent'] ?? 'Heartbeat sent!');
      _fetchLastInteractionTime();
    } catch (e) {
      _displayMessage('Error sending heartbeat: $e');
    }
  }

  Future<void> _sendMessage() async {
    final messageText = _messageController.text.trim();
    if (messageText.isEmpty) return;

    if (_myHeartCode == null || _partnerHeartCode == null) {
      _displayMessage(
          currentStrings['noPartnerPaired'] ?? 'No partner paired yet.');
      return;
    }

    try {
      final messageId =
          FirebaseFirestore.instance.collection('messages').doc().id;
      await FirebaseFirestore.instance
          .collection('messages')
          .doc(messageId)
          .set({
        'senderId': _myHeartCode,
        'receiverId': _partnerHeartCode,
        'text': messageText,
        'timestamp': FieldValue.serverTimestamp(),
      });

      _messageController.clear();
      _displayMessage(currentStrings['messageSent'] ?? 'Message sent!');

      // تحديث آخر تفاعل
      final interactionId = '${_myHeartCode}_$_partnerHeartCode';
      await FirebaseFirestore.instance
          .collection('interactions')
          .doc(interactionId)
          .set(
        {
          'senderId': _myHeartCode,
          'receiverId': _partnerHeartCode,
          'type': 'message',
          'timestamp': FieldValue.serverTimestamp(),
        },
        SetOptions(merge: true),
      );
      _fetchLastInteractionTime(); // تحديث وقت آخر تفاعل

      if (_partnerFcmToken != null && _partnerFcmToken!.isNotEmpty) {
        logger.i(
            'Sending message notification to partner FCM: $_partnerFcmToken');
        // TODO: يمكنك إضافة منطق إرسال إشعار FCM هنا
      }
    } catch (e) {
      _displayMessage('Error sending message: $e');
    }
  }

  void _displayMessage(String message) {
    if (mounted && scaffoldMessengerKey.currentState != null) {
      scaffoldMessengerKey.currentState!.showSnackBar(
        SnackBar(content: Text(message)),
      );
    }
  }

  String _formatTimeAgo(DateTime? dateTime) {
    if (dateTime == null) {
      return currentStrings['never'] ?? 'Never';
    }
    final Duration difference = DateTime.now().difference(dateTime);

    if (difference.inSeconds < 60) {
      return '${difference.inSeconds} ${currentStrings['secondsAgo'] ?? 'seconds ago'}';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes} ${currentStrings['minutesAgo'] ?? 'minutes ago'}';
    } else if (difference.inHours < 24) {
      return '${difference.inHours} ${currentStrings['hoursAgo'] ?? 'hours ago'}';
    } else if (difference.inDays < 30) {
      return '${difference.inDays} ${currentStrings['daysAgo'] ?? 'days ago'}';
    } else {
      return DateFormat('MMM d, yyyy')
          .format(dateTime); // تنسيق التاريخ ليكون أكثر من شهر
    }
  }

  @override
  Widget build(BuildContext context) {
    final Color primaryColor = Theme.of(context).colorScheme.primary;
    final Color tertiaryColor = Theme.of(context).colorScheme.tertiary;

    return Stack(
children: [
Scaffold(
key: Scaffoldkey,
      appBar: AppBar(
        title: Text(currentStrings['appTitle'] ?? 'HeartSync'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const SettingsScreen()),
              );
            },
          ),
],
),

        ],
      ),
      drawer: Drawer(
        child: Container(
          color: Theme.of(context).colorScheme.surface, // استخدام لون السطح
          child: ListView(
            padding: EdgeInsets.zero,
            children: <Widget>[
              DrawerHeader(
                decoration: BoxDecoration(
                  color: primaryColor,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      currentStrings['welcome'] ?? 'Welcome',
                      style: Theme.of(context)
                          .textTheme
                          .headlineSmall
                          ?.copyWith(color: Colors.white),
                    ),
                    Text(
                      _partnerName != null && _partnerName!.isNotEmpty
                          ? '❤️ ${_partnerName!}'
                          : (currentStrings['unknownPartner'] ??
                              'Unknown Partner'),
                      style: Theme.of(context)
                          .textTheme
                          .titleLarge
                          ?.copyWith(color: Colors.white),
                    ),
                  ],
                ),
              ),
              ListTile(
                leading: Icon(Icons.home, color: tertiaryColor),
                title: Text(currentStrings['home'] ?? 'Home',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: Theme.of(context).colorScheme.onSurface)),
                onTap: () {
                  Navigator.pop(context);
                },
              ),
              ListTile(
                leading: Icon(Icons.favorite_border, color: tertiaryColor),
                title: Text(
                    currentStrings['iMissYouSettings'] ?? 'I Miss You Settings',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: Theme.of(context).colorScheme.onSurface)),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const IMissYouSettingsScreen()),
                  );
                },
              ),
              ListTile(
                leading: Icon(Icons.settings, color: tertiaryColor),
                title: Text(currentStrings['settings'] ?? 'Settings',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: Theme.of(context).colorScheme.onSurface)),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const SettingsScreen()),
                  );
                },
              ),
              ListTile(
                leading: Icon(Icons.exit_to_app, color: tertiaryColor),
                title: Text(currentStrings['logout'] ?? 'Logout',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: Theme.of(context).colorScheme.onSurface)),
                onTap: () {
                  // TODO: implement logout logic
                  Navigator.pop(context);
                },
              ),
            ],
          ),
        ),
      ),
      body: _partnerHeartCode == null || _partnerHeartCode!.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.people_alt,
                      size: 80,
                      color: tertiaryColor,
                    ),
                    const SizedBox(height: 20),
                    Text(
                      currentStrings['noPartnerMessage'] ??
                          'It looks like you haven\'t paired with anyone yet. Head to the pairing screen to connect with your partner!',
                      textAlign: TextAlign.center,
                      style: Theme.of(context)
                          .textTheme
                          .titleMedium
                          ?.copyWith(color: Colors.white70),
                    ),
                    const SizedBox(height: 30),
                    ElevatedButton.icon(
                      onPressed: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const PairingScreen()),
                        );
                      },
                      icon: const Icon(Icons.link),
                      label: Text(
                          currentStrings['goToPairing'] ?? 'Go to Pairing'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: primaryColor,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 30, vertical: 15),
                        textStyle: const TextStyle(fontSize: 18),
                      ),
                    ),
                  ],
                ),
              ),
            )
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Theme.of(context)
                          .colorScheme
                          .surface, // استخدام لون السطح
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              currentStrings['lastInteractionWith'] ??
                                  'Last interaction with',
                              style: Theme.of(context)
                                  .textTheme
                                  .titleMedium
                                  ?.copyWith(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurface
                                          .withAlpha(179)), // استخدام withAlpha
                            ),
                            Text(
                              _partnerName ??
                                  (currentStrings['unknownPartner'] ??
                                      'Your Partner'),
                              style: Theme.of(context)
                                  .textTheme
                                  .headlineMedium
                                  ?.copyWith(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurface),
                            ),
                          ],
                        ),
                        Text(
                          _formatTimeAgo(_lastInteractionTime),
                          style: Theme.of(context)
                              .textTheme
                              .bodyLarge
                              ?.copyWith(
                                  color: Theme.of(context)
                                      .colorScheme
                                      .onSurface
                                      .withAlpha(179)), // استخدام withAlpha
                        ),
                      ],
                    ),
                  ),
                  const Spacer(),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8.0),
                    child: TextField(
                      controller: _messageController,
                      decoration: InputDecoration(
                        hintText: currentStrings['typeMessage'] ??
                            'Type a message...',
                        hintStyle: TextStyle(
                            color: Theme.of(context)
                                .colorScheme
                                .onSurface
                                .withAlpha(153)), // استخدام withAlpha
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(25),
                          borderSide: BorderSide.none,
                        ),
                        filled: true,
                        fillColor: Theme.of(context)
                            .colorScheme
                            .surface
                            .withAlpha(179), // استخدام withAlpha
                      ),
                      style: TextStyle(
                          color: Theme.of(context).colorScheme.onSurface),
                      maxLines: null,
                      keyboardType: TextInputType.multiline,
                    ),
                  ),
                 // Row(
                 //  mainAxisAlignment: MainAxisAlignment.end,
                   Expanded(
                 //   children: [  
                       child:[ center(
                    child:  FloatingActionButton(
                        onPressed: _sendMessage,
                        mini: true,
                        backgroundColor: tertiaryColor,
                        child: const Icon(Icons.send, color: Colors.white),
                      ),
                      ),
                      const SizedBox(width: 8),
                      FloatingActionButton(
                        onPressed: _sendHeartbeat,
                        //mini: true,
                        backgroundColor: primaryColor,
                        child: const Icon(Icons.favorite,size:42,color: Colors.white),
                      ),
                    ],
                  ),
                ],
              ),
            ),
    );
  }
}
class TriangleMenuButton extends StatelessWidget {
  final VoidCallback onTap;
  const TriangleMenuButton({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 50,
        height: 40,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.2),
          borderRadius: const BorderRadius.only(
            topRight: Radius.circular(10),
            bottomRight: Radius.circular(10),
          ),
        ),
        child: CustomPaint(
          painter: _TrianglePainter(),
        ),
      ),
    );
  }
}

class _TrianglePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final Paint paint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.fill;

    final Path path = Path();
    path.moveTo(size.width * 0.35, size.height * 0.25); // أعلى
    path.lineTo(size.width * 0.7, size.height * 0.5);   // منتصف المثلث
    path.lineTo(size.width * 0.35, size.height * 0.75); // أسفل
    path.close();

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
