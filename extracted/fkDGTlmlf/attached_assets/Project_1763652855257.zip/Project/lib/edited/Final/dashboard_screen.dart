import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:heartsync/app_strings.dart';
import 'package:heartsync/pairing_screen.dart';
import 'package:heartsync/settings_screen.dart';
import 'package:heartsync/i_miss_you_settings_screen.dart';
import 'package:intl/intl.dart';
import 'package:logger/logger.dart';
import 'dart:async';
import 'dart:math' as math;

final logger = Logger();
final GlobalKey<ScaffoldMessengerState> scaffoldMessengerKey =
    GlobalKey<ScaffoldMessengerState>();

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen>
    with TickerProviderStateMixin {
  String? _partnerName;
  String? _partnerHeartCode;
  String? _myHeartCode;
  String? _partnerFcmToken;
  DateTime? _lastInteractionTime;

  // Animation controllers
  late AnimationController _leftHeartController;
  late AnimationController _rightHeartController;
  late AnimationController _ecgController;
  late AnimationController _slideController;
  late AnimationController _glowController;

  // Animations
  late Animation<double> _leftHeartAnimation;
  late Animation<double> _rightHeartAnimation;
  late Animation<double> _ecgAnimation;
  late Animation<double> _slideAnimation;
  late Animation<double> _glowAnimation;

  bool _isAnimating = false;
  bool _isSliding = false;
  double _slideProgress = 0.0;

  @override
  void initState() {
    super.initState();
    _loadPartnerInfo();
    _listenForInteractions();
    _setupAnimations();
  }

  void _setupAnimations() {
    // Left heart animation
    _leftHeartController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    _leftHeartAnimation = Tween<double>(
      begin: 1.0,
      end: 1.3,
    ).animate(CurvedAnimation(
      parent: _leftHeartController,
      curve: Curves.easeInOut,
    ));

    // Right heart animation
    _rightHeartController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _rightHeartAnimation = Tween<double>(
      begin: 1.0,
      end: 1.25,
    ).animate(CurvedAnimation(
      parent: _rightHeartController,
      curve: Curves.easeInOut,
    ));

    // ECG animation
    _ecgController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    _ecgAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _ecgController,
      curve: Curves.easeInOut,
    ));

    // Slide animation
    _slideController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _slideAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _slideController,
      curve: Curves.easeInOut,
    ));

    // Glow animation
    _glowController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    _glowAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _glowController,
      curve: Curves.easeInOut,
    ));

    _glowController.repeat(reverse: true);
  }

  @override
  void dispose() {
    _leftHeartController.dispose();
    _rightHeartController.dispose();
    _ecgController.dispose();
    _slideController.dispose();
    _glowController.dispose();
    super.dispose();
  }

  Future<void> _loadPartnerInfo() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _partnerName = prefs.getString('partnerName');
      _partnerHeartCode = prefs.getString('partnerHeartCode');
      _myHeartCode = prefs.getString('userHeartCode');
      _partnerFcmToken = prefs.getString('partnerFcmToken');
    });
    if (_partnerHeartCode != null) {
      _fetchLastInteractionTime();
    }
  }

  Future<void> _fetchLastInteractionTime() async {
    if (_myHeartCode == null || _partnerHeartCode == null) return;
    try {
      final docSnapshot = await FirebaseFirestore.instance
          .collection('interactions')
          .doc('${_myHeartCode}_$_partnerHeartCode')
          .get();
      if (docSnapshot.exists) {
        final data = docSnapshot.data();
        if (data != null && data['timestamp'] != null) {
          setState(() {
            _lastInteractionTime = (data['timestamp'] as Timestamp).toDate();
          });
        }
      }
    } catch (e) {
      logger.e("Error fetching last interaction: $e");
    }
  }

  void _listenForInteractions() {
    if (_myHeartCode == null || _partnerHeartCode == null) {
      return;
    }

    FirebaseFirestore.instance
        .collection('interactions')
        .doc('${_partnerHeartCode}_$_myHeartCode')
        .snapshots()
        .listen((snapshot) {
      if (snapshot.exists && snapshot.data() != null) {
        final data = snapshot.data();
        if (data != null && data['timestamp'] != null) {
          setState(() {
            _lastInteractionTime = (data['timestamp'] as Timestamp).toDate();
          });
        }
      }
    });
    FirebaseFirestore.instance
        .collection('interactions')
        .doc('${_myHeartCode}_$_partnerHeartCode')
        .snapshots()
        .listen((snapshot) {
      if (snapshot.exists && snapshot.data() != null) {
        final data = snapshot.data();
        if (data != null && data['timestamp'] != null) {
          setState(() {
            _lastInteractionTime = (data['timestamp'] as Timestamp).toDate();
          });
        }
      }
    });
  }

  Future<void> _sendHeartbeat() async {
    if (_isAnimating) return;
    
    if (_myHeartCode == null || _partnerHeartCode == null) {
      _displayMessage(
          currentStrings['noPartnerPaired'] ?? 'No partner paired yet.');
      return;
    }

    setState(() {
      _isAnimating = true;
    });

    // Start the heart pulse animation
    _startHeartPulseAnimation();

    try {
      final interactionId = '${_myHeartCode}_$_partnerHeartCode';
      await FirebaseFirestore.instance
          .collection('interactions')
          .doc(interactionId)
          .set(
        {
          'senderId': _myHeartCode,
          'receiverId': _partnerHeartCode,
          'type': 'heartbeat',
          'timestamp': FieldValue.serverTimestamp(),
        },
        SetOptions(merge: true),
      );
      if (_partnerFcmToken != null && _partnerFcmToken!.isNotEmpty) {
        logger.i(
            'Sending heartbeat notification to partner FCM: $_partnerFcmToken');
      }
      _displayMessage(currentStrings['heartbeatSent'] ?? 'Heartbeat sent!');
      _fetchLastInteractionTime();
    } catch (e) {
      _displayMessage('Error sending heartbeat: $e');
    }

    // Reset animation state after completion
    Future.delayed(const Duration(milliseconds: 3500), () {
      setState(() {
        _isAnimating = false;
      });
    });
  }

  void _startHeartPulseAnimation() {
    // Left heart pulses first (send)
    _leftHeartController.forward().then((_) {
      _leftHeartController.reverse();
    });

    // ECG animation starts after 600ms
    Future.delayed(const Duration(milliseconds: 600), () {
      _ecgController.forward().then((_) {
        _ecgController.reset();
      });
    });

    // Right heart pulses after 2100ms (receive)
    Future.delayed(const Duration(milliseconds: 2100), () {
      _rightHeartController.forward().then((_) {
        _rightHeartController.reverse();
      });
    });
  }

  Future<void> _sendMessage() async {
    if (_myHeartCode == null || _partnerHeartCode == null) {
      _displayMessage(
          currentStrings['noPartnerPaired'] ?? 'No partner paired yet.');
      return;
    }

    try {
      final messageId =
          FirebaseFirestore.instance.collection('messages').doc().id;
      await FirebaseFirestore.instance
          .collection('messages')
          .doc(messageId)
          .set({
        'senderId': _myHeartCode,
        'receiverId': _partnerHeartCode,
        'text': 'I miss you ❤️',
        'timestamp': FieldValue.serverTimestamp(),
      });

      _displayMessage(currentStrings['messageSent'] ?? 'Message sent!');

      final interactionId = '${_myHeartCode}_$_partnerHeartCode';
      await FirebaseFirestore.instance
          .collection('interactions')
          .doc(interactionId)
          .set(
        {
          'senderId': _myHeartCode,
          'receiverId': _partnerHeartCode,
          'type': 'message',
          'timestamp': FieldValue.serverTimestamp(),
        },
        SetOptions(merge: true),
      );
      _fetchLastInteractionTime();

      if (_partnerFcmToken != null && _partnerFcmToken!.isNotEmpty) {
        logger.i(
            'Sending message notification to partner FCM: $_partnerFcmToken');
      }
    } catch (e) {
      _displayMessage('Error sending message: $e');
    }
  }

  void _displayMessage(String message) {
    if (mounted && scaffoldMessengerKey.currentState != null) {
      scaffoldMessengerKey.currentState!.showSnackBar(
        SnackBar(content: Text(message)),
      );
    }
  }

  String _formatTimeAgo(DateTime? dateTime) {
    if (dateTime == null) {
      return currentStrings['never'] ?? 'Never';
    }
    final Duration difference = DateTime.now().difference(dateTime);

    if (difference.inSeconds < 60) {
      return '${difference.inSeconds} ${currentStrings['secondsAgo'] ?? 'seconds ago'}';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes} ${currentStrings['minutesAgo'] ?? 'minutes ago'}';
    } else if (difference.inHours < 24) {
      return '${difference.inHours} ${currentStrings['hoursAgo'] ?? 'hours ago'}';
    } else if (difference.inDays < 30) {
      return '${difference.inDays} ${currentStrings['daysAgo'] ?? 'days ago'}';
    } else {
      return DateFormat('MMM d, yyyy').format(dateTime);
    }
  }

  void _onSlideUpdate(double progress) {
    setState(() {
      _slideProgress = progress;
    });
  }

  void _onSlideComplete() {
    if (_slideProgress > 0.8) {
      _sendMessage();
      _slideController.forward().then((_) {
        Future.delayed(const Duration(milliseconds: 200), () {
          _slideController.reset();
          setState(() {
            _slideProgress = 0.0;
          });
        });
      });
    } else {
      _slideController.reverse();
      setState(() {
        _slideProgress = 0.0;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final Color primaryColor = Theme.of(context).colorScheme.primary;
    final Color tertiaryColor = Theme.of(context).colorScheme.tertiary;

    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Left Heart
            AnimatedBuilder(
              animation: _leftHeartAnimation,
              builder: (context, child) {
                return Transform.scale(
                  scale: _leftHeartAnimation.value,
                  child: Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                      color: Colors.transparent,
                      borderRadius: BorderRadius.circular(25),
                      boxShadow: _leftHeartController.isAnimating
                          ? [
                              BoxShadow(
                                color: Colors.red.withOpacity(0.8),
                                blurRadius: 20,
                                spreadRadius: 5,
                              ),
                            ]
                          : [],
                    ),
                    child: Icon(
                      Icons.favorite,
                      color: Colors.red,
                      size: 30,
                    ),
                  ),
                );
              },
            ),
            
            const SizedBox(width: 20),
            
            // ECG Line
            SizedBox(
              width: 80,
              height: 30,
              child: AnimatedBuilder(
                animation: _ecgAnimation,
                builder: (context, child) {
                  return CustomPaint(
                    painter: ECGPainter(
                      progress: _ecgAnimation.value,
                      color: primaryColor,
                    ),
                  );
                },
              ),
            ),
            
            const SizedBox(width: 20),
            
            // Right Heart
            AnimatedBuilder(
              animation: _rightHeartAnimation,
              builder: (context, child) {
                return Transform.scale(
                  scale: _rightHeartAnimation.value,
                  child: Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                      color: Colors.transparent,
                      borderRadius: BorderRadius.circular(25),
                      boxShadow: _rightHeartController.isAnimating
                          ? [
                              BoxShadow(
                                color: Colors.pink.withOpacity(0.8),
                                blurRadius: 20,
                                spreadRadius: 5,
                              ),
                            ]
                          : [],
                    ),
                    child: Icon(
                      Icons.favorite,
                      color: Colors.pink,
                      size: 30,
                    ),
                  ),
                );
              },
            ),
          ],
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const SettingsScreen()),
              );
            },
          ),
        ],
      ),
      drawer: Drawer(
        child: Container(
          color: Theme.of(context).colorScheme.surface,
          child: ListView(
            padding: EdgeInsets.zero,
            children: <Widget>[
              DrawerHeader(
                decoration: BoxDecoration(
                  color: primaryColor,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      currentStrings['welcome'] ?? 'Welcome',
                      style: Theme.of(context)
                          .textTheme
                          .headlineSmall
                          ?.copyWith(color: Colors.white),
                    ),
                    Text(
                      _partnerName != null && _partnerName!.isNotEmpty
                          ? '❤️ ${_partnerName!}'
                          : (currentStrings['unknownPartner'] ??
                              'Unknown Partner'),
                      style: Theme.of(context)
                          .textTheme
                          .titleLarge
                          ?.copyWith(color: Colors.white),
                    ),
                  ],
                ),
              ),
              ListTile(
                leading: Icon(Icons.home, color: tertiaryColor),
                title: Text(currentStrings['home'] ?? 'Home',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: Theme.of(context).colorScheme.onSurface)),
                onTap: () {
                  Navigator.pop(context);
                },
              ),
              ListTile(
                leading: Icon(Icons.favorite_border, color: tertiaryColor),
                title: Text(
                    currentStrings['iMissYouSettings'] ?? 'I Miss You Settings',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: Theme.of(context).colorScheme.onSurface)),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const IMissYouSettingsScreen()),
                  );
                },
              ),
              ListTile(
                leading: Icon(Icons.settings, color: tertiaryColor),
                title: Text(currentStrings['settings'] ?? 'Settings',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: Theme.of(context).colorScheme.onSurface)),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const SettingsScreen()),
                  );
                },
              ),
              ListTile(
                leading: Icon(Icons.exit_to_app, color: tertiaryColor),
                title: Text(currentStrings['logout'] ?? 'Logout',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: Theme.of(context).colorScheme.onSurface)),
                onTap: () {
                  Navigator.pop(context);
                },
              ),
            ],
          ),
        ),
      ),
      body: _partnerHeartCode == null || _partnerHeartCode!.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.people_alt,
                      size: 80,
                      color: tertiaryColor,
                    ),
                    const SizedBox(height: 20),
                    Text(
                      currentStrings['noPartnerMessage'] ??
                          'It looks like you haven\'t paired with anyone yet. Head to the pairing screen to connect with your partner!',
                      textAlign: TextAlign.center,
                      style: Theme.of(context)
                          .textTheme
                          .titleMedium
                          ?.copyWith(color: Colors.white70),
                    ),
                    const SizedBox(height: 30),
                    ElevatedButton.icon(
                      onPressed: () {
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const PairingScreen()),
                        );
                      },
                      icon: const Icon(Icons.link),
                      label: Text(
                          currentStrings['goToPairing'] ?? 'Go to Pairing'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: primaryColor,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 30, vertical: 15),
                        textStyle: const TextStyle(fontSize: 18),
                      ),
                    ),
                  ],
                ),
              ),
            )
          : Column(
              children: [
                // معلومات الشريك في الأعلى
                Container(
                  margin: const EdgeInsets.all(16),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surface,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            currentStrings['lastInteractionWith'] ??
                                'Last interaction with',
                            style: Theme.of(context)
                                .textTheme
                                .titleMedium
                                ?.copyWith(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onSurface
                                        .withAlpha(179)),
                          ),
                          Text(
                            _partnerName ??
                                (currentStrings['unknownPartner'] ??
                                    'Your Partner'),
                            style: Theme.of(context)
                                .textTheme
                                .headlineMedium
                                ?.copyWith(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onSurface),
                          ),
                        ],
                      ),
                      Text(
                        _formatTimeAgo(_lastInteractionTime),
                        style: Theme.of(context)
                            .textTheme
                            .bodyLarge
                            ?.copyWith(
                                color: Theme.of(context)
                                    .colorScheme
                                    .onSurface
                                    .withAlpha(179)),
                      ),
                    ],
                  ),
                ),
                
                // زر القلب الكبير في الوسط
                Expanded(
                  child: Center(
                    child: GestureDetector(
                      onTap: _sendHeartbeat,
                      child: AnimatedBuilder(
                        animation: _glowAnimation,
                        builder: (context, child) {
                          return Container(
                            width: 200,
                            height: 200,
                            decoration: BoxDecoration(
                              color: primaryColor,
                              borderRadius: BorderRadius.circular(100),
                              boxShadow: [
                                BoxShadow(
                                  color: primaryColor.withOpacity(0.3 + (_glowAnimation.value * 0.4)),
                                  blurRadius: 20 + (_glowAnimation.value * 20),
                                  spreadRadius: 5 + (_glowAnimation.value * 5),
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.favorite,
                              color: Colors.white,
                              size: 100,
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ),
                
                // زر الانزلاق في الربع السفلي
                Padding(
                  padding: const EdgeInsets.all(32.0),
                  child: SlideToSendButton(
                    onSlideComplete: _onSlideComplete,
                    onSlideUpdate: _onSlideUpdate,
                    slideProgress: _slideProgress,
                    primaryColor: primaryColor,
                    tertiaryColor: tertiaryColor,
                    glowAnimation: _glowAnimation,
                  ),
                ),
              ],
            ),
    );
  }
}

class ECGPainter extends CustomPainter {
  final double progress;
  final Color color;

  ECGPainter({required this.progress, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final path = Path();
    final width = size.width;
    final height = size.height;
    final centerY = height / 2;

    // ECG wave points
    final points = [
      Offset(0, centerY),
      Offset(width * 0.2, centerY),
      Offset(width * 0.25, centerY - height * 0.6),
      Offset(width * 0.3, centerY + height * 0.8),
      Offset(width * 0.35, centerY - height * 0.4),
      Offset(width * 0.4, centerY + height * 0.2),
      Offset(width * 0.45, centerY),
      Offset(width, centerY),
    ];

    // Draw ECG line based on progress
    if (progress > 0) {
      path.moveTo(points[0].dx, points[0].dy);
      
      for (int i = 1; i < points.length; i++) {
        final segmentProgress = (progress * (points.length - 1)) - (i - 1);
        if (segmentProgress > 0) {
          if (segmentProgress >= 1) {
            path.lineTo(points[i].dx, points[i].dy);
          } else {
            final prevPoint = points[i - 1];
            final currentPoint = points[i];
            final x = prevPoint.dx + (currentPoint.dx - prevPoint.dx) * segmentProgress;
            final y = prevPoint.dy + (currentPoint.dy - prevPoint.dy) * segmentProgress;
            path.lineTo(x, y);
            break;
          }
        }
      }
      
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

class SlideToSendButton extends StatefulWidget {
  final VoidCallback onSlideComplete;
  final Function(double) onSlideUpdate;
  final double slideProgress;
  final Color primaryColor;
  final Color tertiaryColor;
  final Animation<double> glowAnimation;

  const SlideToSendButton({
    Key? key,
    required this.onSlideComplete,
    required this.onSlideUpdate,
    required this.slideProgress,
    required this.primaryColor,
    required this.tertiaryColor,
    required this.glowAnimation,
  }) : super(key: key);

  @override
  State<SlideToSendButton> createState() => _SlideToSendButtonState();
}

class _SlideToSendButtonState extends State<SlideToSendButton> {
  double _dragPosition = 0.0;
  bool _isDragging = false;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.glowAnimation,
      builder: (context, child) {
        return Container(
          height: 70,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(35),
            gradient: LinearGradient(
              colors: [
                widget.primaryColor.withOpacity(0.3),
                widget.tertiaryColor.withOpacity(0.3),
              ],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
            boxShadow: [
              BoxShadow(
                color: widget.primaryColor.withOpacity(0.3 * widget.glowAnimation.value),
                blurRadius: 15,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Stack(
            children: [
              // الخلفية مع الأسهم المتحركة
              Positioned.fill(
                child: CustomPaint(
                  painter: ArrowPatternPainter(
                    progress: _dragPosition,
                    glowProgress: widget.glowAnimation.value,
                    color: widget.primaryColor,
                  ),
                ),
              ),
              
              // النص في المنتصف
              Center(
                child: Text(
                  'اسحب لإرسال "اشتقت إليك"',
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.8),
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              
              // زر الانزلاق
              Positioned(
                left: _dragPosition,
                top: 5,
                child: GestureDetector(
                  onPanStart: (_) {
                    setState(() {
                      _isDragging = true;
                    });
                  },
                  onPanUpdate: (details) {
                    setState(() {
                      _dragPosition = (_dragPosition + details.delta.dx)
                          .clamp(0.0, MediaQuery.of(context).size.width - 120);
                      widget.onSlideUpdate(
                          _dragPosition / (MediaQuery.of(context).size.width - 120));
                    });
                  },
                  onPanEnd: (_) {
                    setState(() {
                      _isDragging = false;
                    });
                    widget.onSlideComplete();
                    if (_dragPosition < (MediaQuery.of(context).size.width - 120) * 0.8) {
                      setState(() {
                        _dragPosition = 0.0;
                      });
                    }
                  },
                  child: Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      color: widget.primaryColor,
                      borderRadius: BorderRadius.circular(30),
                      boxShadow: [
                        BoxShadow(
                          color: widget.primaryColor.withOpacity(0.5),
                          blurRadius: _isDragging ? 15 : 8,
                          spreadRadius: _isDragging ? 3 : 1,
                        ),
                      ],
                    ),
                    child: Icon(
                      Icons.favorite,
                      color: Colors.white,
                      size: _isDragging ? 30 : 24,
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class ArrowPatternPainter extends CustomPainter {
  final double progress;
  final double glowProgress;
  final Color color;

  ArrowPatternPainter({
    required this.progress,
    required this.glowProgress,
    required this.color,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withOpacity(0.3 + (glowProgress * 0.4))
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;

    // رسم الأسهم المتحركة
    for (int i = 0; i < 8; i++) {
      double x = (i * 40.0) + (progress * 30) - 20;
      if (x > -20 && x < size.width + 20) {
        // رسم السهم
        Path arrowPath = Path();
        arrowPath.moveTo(x, size.height / 2 - 8);
        arrowPath.lineTo(x + 12, size.height / 2);
        arrowPath.lineTo(x, size.height / 2 + 8);
        arrowPath.moveTo(x, size.height / 2);
        arrowPath.lineTo(x + 12, size.height / 2);
        
        canvas.drawPath(arrowPath, paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}